# tests/test_mongo_logger.py

import pytest
from core import mongo_logger


def test_log_ia_action(monkeypatch):
    class FakeCollection:
        def insert_one(self, data):
            assert data['user_id'] == 1
            assert data['type'] == 'summary'
            assert 'input' in data and 'result' in data
            return True

    class FakeDB:
        def __getitem__(self, name):
            return FakeCollection()

    class FakeClient:
        def __getitem__(self, name):
            return FakeDB()

    monkeypatch.setattr(mongo_logger, 'client', FakeClient())
    mongo_logger.log_ia_action(
        user_id=1,
        action_type='summary',
        input_data={'text': 'Exemplo'},
        result_data={'summary': 'Resumo gerado'}
    )
