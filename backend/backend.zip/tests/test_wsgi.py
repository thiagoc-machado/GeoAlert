def test_import_wsgi():
    import geoalert.wsgi
    assert True