def test_import_asgi():
    import geoalert.asgi
    assert True