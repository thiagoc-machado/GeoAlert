# core/authentication.py
from rest_framework.authentication import BaseAuthentication
from rest_framework.exceptions import AuthenticationFailed
from django.contrib.auth import get_user_model
import jwt
import requests

User = get_user_model()

class KeycloakAuthentication(BaseAuthentication):
    def authenticate(self, request):
        auth_header = request.headers.get('Authorization')

        if not auth_header or not auth_header.startswith('Bearer '):
            return None

        token = auth_header.split(' ')[1]

        try:
            # Busca chave pública do Keycloak via JWKS
            jwks_url = 'http://keycloak:8080/realms/geoalert/protocol/openid-connect/certs'
            jwks = requests.get(jwks_url).json()
            public_key = jwt.algorithms.RSAAlgorithm.from_jwk(jwks['keys'][0])

            decoded = jwt.decode(
                token,
                key=public_key,
                algorithms=['RS256'],
                options={'verify_exp': True, 'verify_aud': False}
            )

            username = decoded.get('preferred_username')
            email = decoded.get('email')

            if not username or not email:
                raise AuthenticationFailed('Token inválido.')

            user, _ = User.objects.get_or_create(username=username, defaults={'email': email})
            return (user, None)

        except Exception as e:
            raise AuthenticationFailed(f'Falha ao autenticar token: {str(e)}')
